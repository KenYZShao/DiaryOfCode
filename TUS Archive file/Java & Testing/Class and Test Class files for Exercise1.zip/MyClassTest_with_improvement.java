import org.junit.jupiter.api.BeforeEach;
// more import statements


class MyClassTest {

private MyClass tester;

@BeforeEach
void setup() {
    tester = new MyClass();
}

// tests are before
}