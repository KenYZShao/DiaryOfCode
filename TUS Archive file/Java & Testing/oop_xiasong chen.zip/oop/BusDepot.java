package oop;

import java.util.Scanner;

/**
 * @author Xiasong Chen A00291322
 * 
 * @date 25 Jul 2022 9:26:21
 * @version 1.0
 */

class Bus {
	private int theNumberOfSeats;
	private String theDriversName;
	private String theMake;
	private static int theCount;

	public Bus() {
		theCount++;
	}

	public Bus(int theNumberOfSeats, String theDriversName, String theMake) {
		super();
		this.theNumberOfSeats = theNumberOfSeats;
		this.theDriversName = theDriversName;
		this.theMake = theMake;
		theCount++;
	}

	public int getNumberOfSeats() {
		return theNumberOfSeats;
	}

	public void setNumberOfSeats(int theNumberOfSeats) {
		this.theNumberOfSeats = theNumberOfSeats;
	}

	public String getDriversName() {
		return theDriversName;
	}

	public void setDriversName(String theDriversName) {
		this.theDriversName = theDriversName;
	}

	public String getMake() {
		return theMake;
	}

	public void setMake(String theMake) {
		this.theMake = theMake;
	}

	public static int getCount() {
		return theCount;
	}

	@Override
	public String toString() {
		return String.format("theDriversName: %s, theMake: %s, theNumberOfSeats: %s", theDriversName, theMake,
				theNumberOfSeats);
	}
}

public class BusDepot {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		// 1
		Bus bus = new Bus();
		// 2
		Bus busMichael = new Bus(60, "Michael", "Volvo");
		// 3
		System.out.println(bus);
		System.out.println(busMichael);
		System.out.println(Bus.getCount());
		// 5
		String driversName = getDriver();
		String make = getMake();
		int seats = getNumberOfSeats();
		// 7
		Bus bus3 = new Bus(seats, driversName, make);
		System.out.println(bus3);
		System.out.println(Bus.getCount());
	}

	public static String getDriver() {
		// 4
		System.out.println("Enter the Driver");
		String name = sc.next();
		return name;
	}

	public static String getMake() {
		System.out.println("Enter the Make");
		return sc.next();
	}

	public static int getNumberOfSeats() {
		System.out.println("Enter the Seats");
		return sc.nextInt();
	}
}
