package oop;

/**
 * @author Xiasong Chen A00291322
 * 
 * @date 25 Jul 2022 9:15:15
 * @version 1.0
 */

class Customer {
	private int accountNo;
	private double balance;
	private String name;
	private static int count;

	public Customer() {
		count++;
	}

	public Customer(int accountNo, double balance, String name) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.name = name;
		count++;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static int getCount() {
		return count;
	}

	@Override
	public String toString() {
		return String.format("name: %s, accountNo: %s, balance: %s", name, accountNo, balance);
	}

	public double lodge(double money) {
		balance += money;
		return balance;
	}

	public boolean withdrwa(double money) {
		if (balance >= money) {
			balance -= money;
			return true;
		} else {
			System.out.println("balance not enough");
			return false;
		}

	}
}

public class Bank {

	public static void main(String[] args) {
		// 1a
		Customer customerJoe = new Customer();
		customerJoe.setName("Joe Bloggs");
		customerJoe.setAccountNo(1221);
		customerJoe.setBalance(100);
		System.out.println(String.format("name: %s, accountNo: %s, balance: %s", customerJoe.getName(),
				customerJoe.getAccountNo(), customerJoe.getBalance()));
		// 1b
		Customer customerAnn = new Customer(4443, 200, "Ann Bloggs");
		System.out.println(customerAnn.toString());

		// 1c
		System.out.println(Customer.getCount());

		// 2
		System.out.println(customerJoe);
		customerJoe.setName("Joseph Bloggs");
		System.out.println(customerJoe);

		// 3
		customerAnn.withdrwa(250);
		System.out.println(customerAnn);
		customerAnn.lodge(100);
		System.out.println(customerAnn);
		customerAnn.withdrwa(250);
		System.out.println(customerAnn);

	}

}
