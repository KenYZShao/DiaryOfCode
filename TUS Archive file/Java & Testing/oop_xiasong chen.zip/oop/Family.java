package oop;

/**
 * @author Xiasong Chen A00291322
 * 
 * @date 25 Jul 2022 9:08:31
 * @version 1.0
 */

class Person {
	private int age;
	private String name;
	private String address;
	private static int count;

	public Person(int age, String name, String address) {
		super();
		setAge(age);
		this.name = name;
		this.address = address;
		count++;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if (age <= 0) {
			System.out.println("Invalid age");
		} else
			this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public static int getCount() {
		return count;
	}

	@Override
	public String toString() {
		return String.format("name: %s, age: %s, address: %s", name, age, address);
	}

}

public class Family {

	public static void main(String[] args) {
		// 1a
		Person john = new Person(22, "John", "Dublin");
		Person ann = new Person(25, "Ann", "Galway");
		Person jack = new Person(15, "Jack", "Athlone");
		// 1b
		System.out.println(Person.getCount());

		// 2
		System.out.println("John's address " + john.getAddress());
		john.setAddress("Galway");
		System.out.println("John's address " + john.getAddress());

		// 3a
		ann.setAge(-2);

		// 3b
		ann.setAge(26);
		System.out.println("Ann's info" + ann.toString());

		// 4
		System.out.println(jack);
		jack.setName("JJ");
		System.out.println(jack);
	}

}
