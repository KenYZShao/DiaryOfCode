package oop;

import java.util.Scanner;

/**
 * @author Xiasong Chen A00291322
 * 
 * @date 25 Jul 2022 20:53:53
 * @version 1.0
 */

class Biscuit {
	private int theNumberOfBiscuits;
	private String theTypeOfBiscuit, theCompany, theLocation;

	Biscuit(int theNumberOfBiscuits, String theTypeOfBiscuit, String theCompany, String theLocation) {
		this.theNumberOfBiscuits = theNumberOfBiscuits;
		this.theTypeOfBiscuit = theTypeOfBiscuit;
		this.theCompany = theCompany;
		this.theLocation = theLocation;
	}

	Biscuit() {
		this.theNumberOfBiscuits = 0;
		this.theTypeOfBiscuit = "";
		this.theCompany = "";
		this.theLocation = "";
	}

	public int getNumberOfBiscuits() {
		return theNumberOfBiscuits;
	}

	public void setNumberOfBiscuits(int theNumberOfBiscuits) {
		this.theNumberOfBiscuits = theNumberOfBiscuits;
	}

	public String getTypeOfBiscuit() {
		return theTypeOfBiscuit;
	}

	public void setTypeOfBiscuit(String theTypeOfBiscuit) {
		this.theTypeOfBiscuit = theTypeOfBiscuit;
	}

	public String getCompany() {
		return theCompany;
	}

	public void setCompany(String theCompany) {
		this.theCompany = theCompany;
	}

	public String getLocation() {
		return theLocation;
	}

	public void setLocation(String theLocation) {
		this.theLocation = theLocation;
	}

	@Override
	public String toString() {
		return String.format("theCompany: %s, theNumberOfBiscuits: %s, theTypeOfBiscuit: %s, theLocation: %s",
				theCompany, theNumberOfBiscuits, theTypeOfBiscuit, theLocation);
	}
}

public class BiscuitFactory {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		// 1
		Biscuit b1 = new Biscuit();
		// 2
		b1.setCompany("McVities");
		b1.setNumberOfBiscuits(20);
		b1.setTypeOfBiscuit("Digestive");
		b1.setLocation("Manchester");
		System.out.println(b1);

		// 3
		Biscuit b2 = new Biscuit(30, "Mikado", "Kimberleys", "Dublin");
		System.out.println(b2);

		// 4
		String typeOfBiscuit = getTypeOfBiscuit();
		String company = getCompany();
		int numBiscuits = getNumBiscuits();
		BiscuitFactory bf = new BiscuitFactory();
		String location = bf.getLocation();
		Biscuit b3 = new Biscuit(numBiscuits, typeOfBiscuit, company, location);
		System.out.println(b3);

	}

	public static int getNumBiscuits() {
		System.out.println("Enter Number of biscuits: ");
		return sc.nextInt();
	}

	public static String getCompany() {
		System.out.println("Enter Company Name: ");
		return sc.next();
	}

	public static String getTypeOfBiscuit() {
		System.out.println("Enter type of biscuit: ");
		return sc.next();
	}

	public String getLocation() {
		System.out.println("Enter Company Location: ");
		return sc.next();
	}
}
