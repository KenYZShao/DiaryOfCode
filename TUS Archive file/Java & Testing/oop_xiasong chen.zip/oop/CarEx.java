package oop;

/**
 * @author Xiasong Chen A00291322
 * 
 * @date 25 Jul 2022 10:37:20
 * @version 1.0
 */
class MotorCar {
	private String theCarModel;
	private String theCarType;
	private int theAgeOfCar;

	public MotorCar(String theCarModel, String theCarType, int theAgeOfCar) {
		super();
		this.theCarModel = theCarModel;
		this.theCarType = theCarType;
		this.theAgeOfCar = theAgeOfCar;
	}

	public String getTheCarModel() {
		return theCarModel;
	}

	public void setTheCarModel(String theCarModel) {
		this.theCarModel = theCarModel;
	}

	public String getTheCarType() {
		return theCarType;
	}

	public void setTheCarType(String theCarType) {
		this.theCarType = theCarType;
	}

	public int getTheAgeOfCar() {
		return theAgeOfCar;
	}

	public void setTheAgeOfCar(int theAgeOfCar) {
		this.theAgeOfCar = theAgeOfCar;
	}

	@Override
	public String toString() {
		return String.format("theCarModel: %s, theCarType: %s, theAgeOfCar: %s", theCarModel, theCarType, theAgeOfCar);
	}
}

class Driver {
	private String theName;
	private String theAddres;
	private boolean drinkDrvingOffence;
	private boolean caughtWithoutASeatbelt;
	private boolean dangerousOvertaking;
	private boolean usingMobileWhileDriving;
	private boolean drvingDefectiveVehicle;
	private boolean crossingContinuousWhiteline;
	private int theTotalPenaltyPoings;
	private MotorCar theCar;

	@Override
	public String toString() {
		return String.format("theName: %s, theAddres: %s, drinkDrvingOffence: %s,\r\n"
				+ "				caughtWithoutASeatbelt: %s, dangerousOvertaking: %s, usingMobileWhileDriving: %s, drvingDefectiveVehicle: %s,\r\n"
				+ "				crossingContinuousWhiteline: %s, theTotalPenaltyPoings: %s, theCar: %s", theName,
				theAddres, drinkDrvingOffence, caughtWithoutASeatbelt, dangerousOvertaking, usingMobileWhileDriving,
				drvingDefectiveVehicle, crossingContinuousWhiteline, theTotalPenaltyPoings, theCar);
	}

	public String getTheName() {
		return theName;
	}

	public void setTheName(String theName) {
		this.theName = theName;
	}

	public String getTheAddres() {
		return theAddres;
	}

	public void setTheAddres(String theAddres) {
		this.theAddres = theAddres;
	}

	public boolean isDrinkDrvingOffence() {
		return drinkDrvingOffence;
	}

	public void setDrinkDrvingOffence(boolean drinkDrvingOffence) {
		this.drinkDrvingOffence = drinkDrvingOffence;
	}

	public boolean isCaughtWithoutASeatbelt() {
		return caughtWithoutASeatbelt;
	}

	public void setCaughtWithoutASeatbelt(boolean caughtWithoutASeatbelt) {
		this.caughtWithoutASeatbelt = caughtWithoutASeatbelt;
	}

	public boolean isDangerousOvertaking() {
		return dangerousOvertaking;
	}

	public void setDangerousOvertaking(boolean dangerousOvertaking) {
		this.dangerousOvertaking = dangerousOvertaking;
	}

	public boolean isUsingMobileWhileDriving() {
		return usingMobileWhileDriving;
	}

	public void setUsingMobileWhileDriving(boolean usingMobileWhileDriving) {
		this.usingMobileWhileDriving = usingMobileWhileDriving;
	}

	public boolean isDrvingDefectiveVehicle() {
		return drvingDefectiveVehicle;
	}

	public void setDrvingDefectiveVehicle(boolean drvingDefectiveVehicle) {
		this.drvingDefectiveVehicle = drvingDefectiveVehicle;
	}

	public boolean isCrossingContinuousWhiteline() {
		return crossingContinuousWhiteline;
	}

	public void setCrossingContinuousWhiteline(boolean crossingContinuousWhiteline) {
		this.crossingContinuousWhiteline = crossingContinuousWhiteline;
	}

	public int getTheTotalPenaltyPoings() {
		return theTotalPenaltyPoings;
	}

	public void setTheTotalPenaltyPoings(int theTotalPenaltyPoings) {
		this.theTotalPenaltyPoings = theTotalPenaltyPoings;
	}

	public MotorCar getTheCar() {
		return theCar;
	}

	public void setTheCar(MotorCar theCar) {
		this.theCar = theCar;
	}

	final int DRINGDRIVING = 5, NOSEATBELT = 5, DANGEROUSOVERTAKING = 5, USEMOBILEPHONE = 4, DEFECTIVEVEHICLE = 5,
			CROSSINGLINE = 4;

	public void calculatePenaltyPoints() {
		if (drinkDrvingOffence) {
			theTotalPenaltyPoings += DRINGDRIVING;
		}
		if (caughtWithoutASeatbelt) {
			theTotalPenaltyPoings += NOSEATBELT;
		}
		if (dangerousOvertaking) {
			theTotalPenaltyPoings += DANGEROUSOVERTAKING;
		}
		if (usingMobileWhileDriving) {
			theTotalPenaltyPoings += USEMOBILEPHONE;
		}
		if (drvingDefectiveVehicle) {
			theTotalPenaltyPoings += DEFECTIVEVEHICLE;
		}
		if (crossingContinuousWhiteline) {
			theTotalPenaltyPoings += CROSSINGLINE;
		}

	}

	public boolean isDisqualified() {
		if (theTotalPenaltyPoings >= 12)
			return true;
		else
			return false;
	}

	public Driver(String theName, String theAddres, MotorCar theCar) {
		super();
		this.theName = theName;
		this.theAddres = theAddres;
		this.drinkDrvingOffence = false;
		this.caughtWithoutASeatbelt = false;
		this.dangerousOvertaking = false;
		this.usingMobileWhileDriving = false;
		this.drvingDefectiveVehicle = false;
		this.crossingContinuousWhiteline = false;
		this.theTotalPenaltyPoings = 0;
		this.theCar = theCar;
	}

	public Driver(String theName, String theAddres, boolean drinkDrvingOffence, boolean caughtWithoutASeatbelt,
			boolean dangerousOvertaking, boolean usingMobileWhileDriving, boolean drvingDefectiveVehicle,
			boolean crossingContinuousWhiteline, int theTotalPenaltyPoings, MotorCar theCar) {
		super();
		this.theName = theName;
		this.theAddres = theAddres;
		this.drinkDrvingOffence = drinkDrvingOffence;
		this.caughtWithoutASeatbelt = caughtWithoutASeatbelt;
		this.dangerousOvertaking = dangerousOvertaking;
		this.usingMobileWhileDriving = usingMobileWhileDriving;
		this.drvingDefectiveVehicle = drvingDefectiveVehicle;
		this.crossingContinuousWhiteline = crossingContinuousWhiteline;
		this.theTotalPenaltyPoings = theTotalPenaltyPoings;
		this.theCar = theCar;
	}

}

public class CarEx {

	public static void main(String[] args) {
		// 1
		MotorCar car = new MotorCar("BMW", "325", 1);
		Driver driverJoe = new Driver("Joe Driver", "someplace dodgy", true, true, false, true, false, true, 0, car);
		// 2
		System.out.println(driverJoe);
		// 3
		driverJoe.calculatePenaltyPoints();
		System.out.println(driverJoe.getTheTotalPenaltyPoings());
		// 4
		driverJoe.setDrvingDefectiveVehicle(true);
		System.out.println(driverJoe.getTheTotalPenaltyPoings());
		// 5
		boolean isDisqualified = driverJoe.isDisqualified();
		if (isDisqualified) {
			System.out.println("Joe is Disqualified");
			System.out.println(driverJoe);
		} else {
			System.out.println("Joe is fine");
			System.out.println(driverJoe);
		}
		// 6
		car = new MotorCar("Volvo", "S40", 4);
		Driver johnCivil = new Driver("John", "someplace nice", car);
		// 7
		johnCivil.calculatePenaltyPoints();
		System.out.println(johnCivil.getTheTotalPenaltyPoings());
		// 8
		johnCivil.setUsingMobileWhileDriving(true);
		johnCivil.calculatePenaltyPoints();
		System.out.println(johnCivil.getTheTotalPenaltyPoings());
		// 9
		isDisqualified = johnCivil.isDisqualified();
		if (isDisqualified) {
			System.out.println("Joe is Disqualified");
			System.out.println(johnCivil);
		} else {
			System.out.println("Joe is fine");
			System.out.println(johnCivil);
		}

	}

}
