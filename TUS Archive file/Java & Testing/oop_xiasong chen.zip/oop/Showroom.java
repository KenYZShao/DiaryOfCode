package oop;

import java.util.Scanner;

/**
 * @author Xiasong Chen A00291322
 * 
 * @date 25 Jul 2022 9:40:00
 * @version 1.0
 */

class Car {
	private String theMake;
	private String theModel;
	private double theEngineSize;
	private static int count;
	private boolean automatic;
	private String theColour;

	public Car() {
		count++;
	}

	public Car(String theMake, String theModel, double theEngineSize, boolean automatic, String theColour) {
		super();
		this.theMake = theMake;
		this.theModel = theModel;
		this.theEngineSize = theEngineSize;
		this.automatic = automatic;
		this.theColour = theColour;
	}

	public String getMake() {
		return theMake;
	}

	public void setMake(String theMake) {
		this.theMake = theMake;
	}

	public String getModel() {
		return theModel;
	}

	public void setModel(String theModel) {
		this.theModel = theModel;
	}

	public double getEngineSize() {
		return theEngineSize;
	}

	public void setEngineSize(double theEngineSize) {
		this.theEngineSize = theEngineSize;
	}

	public static int getCount() {
		return count;
	}

	public boolean isAutomatic() {
		return automatic;
	}

	public void setAutomatic(boolean automatic) {
		this.automatic = automatic;
	}

	public String getColour() {
		return theColour;
	}

	public void setColour(String theColour) {
		this.theColour = theColour;
	}

	@Override
	public String toString() {
		return String.format("theMake: %s, theModel: %s, theEngineSize: %s, automatic: %s, theColour: %s", theMake,
				theModel, theEngineSize, automatic, theColour);
	}
}

public class Showroom {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		// 1
		Car car = new Car();
		// 2
		car.setMake("Ford");
		car.setModel("Mondeo");
		car.setEngineSize(1.6);
		car.setAutomatic(true);
		car.setColour("black");
		System.out.println(car);
		// 3
		Car carVW = new Car("VW", "Passat", 2.0, false, "silver");
		System.out.println(carVW);
		// 4
		System.out.println(Car.getCount());
		// 5
		Car carUser = new Car(getMake(), getModel(), getEngineSize(), isAutomatic(), getColour());
		System.out.println(carUser);
		System.out.println(Car.getCount());

	}

	public static String getMake() {
		System.out.println("Enter the Make");
		String make = sc.next();
		return make;
	}

	public static String getModel() {
		System.out.println("Enter the Model");
		return sc.next();
	}

	public static double getEngineSize() {
		System.out.println("Enter the EngineSize");
		return sc.nextDouble();
	}

	public static String getColour() {
		System.out.println("Enter the Colour");
		return sc.next();
	}

	public static boolean isAutomatic() {
		System.out.println("Is it Automatic");
		return sc.nextBoolean();
	}
}
