/**
 * 
 */
package ie.test.hello;

/**
 * @author Una.Fleming
 *
 */
public class HelloWorld {
	

	public String say() {
		return null;	
		
	}

	public int age() {
		return 0;
	}
	
	
}
