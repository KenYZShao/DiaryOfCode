/**
 * 
 */
package ie.test.hellotest;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.platform.commons.annotation.Testable;

import ie.test.hello.BeforeEach;
import ie.test.hello.Expectation;
import ie.test.hello.HelloWorld;

/**
 * @author Una.Fleming
 *
 */
public class HelloWorldTest {
	
	HelloWorld hello;
	
	
	@BeforeAll
	public void setUp() throws Exception{
		hello =new HelloWorld();
	}

	
	
	@Testable
	public void test() {
		fail("Not yet implemented");
	
	}
	
	@Testable
	void testAge() {
		hello = new HelloWorld();
		assertEquals(hello.age(), 3);
	}
}
