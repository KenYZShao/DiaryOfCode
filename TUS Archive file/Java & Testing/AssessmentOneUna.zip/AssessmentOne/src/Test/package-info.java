package Test;
/**
* 
*/
/**
* @author Una.Fleming
*
*/
import java.util.Scanner;

public class Assessment.One{ //Open Assessment One
	


	public static void main(String [] args) {    // start of main
		

		static Scanner sc = new Scanner(System.in);
		
		allowToDive()
		
		System.out.println("Please write true/false");
		
		System.out.print("Have you a full drivers licence? ");
			boolean licence = sc.nextBoolean();
			if(!licence ==true) {
			System.out.println("Sorry, you cannot drive the car");
			return;
			
			}else if{ System.out.println("Is your car insured?");
				boolean insurance = sc.nextBoolean();
			}boolean insurance;
			if(!insurance ==true) {
				System.out.println("Sorry, you cannot drive the car");
				return;
		
				}else if{ System.out.println("Is your car taxed?");
					boolean tax = sc.nextBoolean();
					if(!tax ==true) {
					System.out.println("Sorry, you cannot drive the car");
				}else {
						System.out.println("Enjoy Driving your Car");
					}
				} 
				
				
			//evenNumbers()
			
			//calcGolfFees()
			
			//goldResort()		
			
				
	}		// end main
				
				
	
//Q1
		public static boolean allowToDive() {
				boolean liscence = "", boolean insurance = "", boolean tax = "";
				
				if (liscence==true){
					System.out.print("Is your car taxed? ");
					return;
			
				}
				return true;
	
		} // end 1
		
		
//Q2		
			
		public static void evenNUmbers() {
			System.out.print("Please low number: ");
			int low=sc.nextInt();
			System.out.print("Please high number: ");
			int high=sc.nextInt();
				
			for(int i=low;i<=high;i++) {
				if(i%2==0) 
					continue;			
				System.out.println(i);
			}
				
		}		// end 2
	
//Q3
			
		public static int calcGolfFees() {
			System.out.print("Enter your age ---> ");
				int age = sc.nextInt();
			
			if (age>=60){
				System.out.print("Senior fee is 60euro");
				
			}else if (age>=18-59){
				System.out.print("Adult fee is 50euro ");
			
			
			}else if (age>=10-17){
				System.out.print("Teen fee is 20euro ");
			
			}else {
				System.out.println("to young");
			}
			
			
		// 10% extra on weekends


//Q4
			public static void golfResort()	{ 
				String dayOfWeek = sc.next();
				int MonCount = 0, TueCount = 0, WedCount = 0, ThurCount = 0, FriCount = 0, SatCount = 0, SunCount = 0,;
			
				while(!dayOfWeek.equals("x")) {
					switch(dayOfWeek ){
						case "Mon":
							MonCount++;
							break;
						case "Tue":
							TueCount++;
							break;
						case "Wed":
							WedCount++;
							break;				
						case "Thur":
							ThurCount++;
							break;
						case "Fri":
							FriCount++;
							break;
						case "Sat":
							SatCount++;
							break;
						case "Sun":
							SunCount++;
							break;	
						default:
							System.out.println("Error: "+ dayOfWeek);
							break;
					
					}
					dayOfWeek = sc.next();
				}
					
			
				System.out.println("Number of A's is " + MonCount);
				System.out.println("Number of B's is " + TueCount);
				System.out.println("Number of C's is " + WedCount);
				System.out.println("Number of D's is " + ThurCount);
				System.out.println("Number of E's is " + FriCount);
				System.out.println("Number of F's is " + SatCount);
				System.out.println("Number of F's is " + SunCount);
			}

			
		} return "";
		
		
	

	
}	// end of AssessmentOne

	