/**
 * 
 */
/**
 * @author Una.Fleming
 *
 */
package Exam;

import java.util.Scanner;

public class Assessment { //Open Assessment One

	private static Scanner sc = new Scanner(System.in);
	
	private static boolean licence = false;
	private static boolean insurance = false;
	private static boolean tax = false;
	
	public static void main(String [] args) { // start of main
		System.out.println("Please write true/false");
		
		System.out.print("Have you a full drivers licence? ");
		licence = sc.nextBoolean();
		if(!licence ==true) {
			System.out.println("Sorry, you cannot drive the car");
			return;
		}
		else {
			System.out.println("Is your car insured?");
			insurance = sc.nextBoolean();
		}
		if(!insurance ==true) {
			System.out.println("Sorry, you cannot drive the car");
			return;
	
		}
		else { System.out.println("Is your car taxed?");
			tax = sc.nextBoolean();
			if(!tax ==true) {
				System.out.println("Sorry, you cannot drive the car");
			}
			else {
				System.out.println("Enjoy Driving your Car");
			}
		}

			
			
		// evenNumbers();
		
		int currentFee = calcGolfFees();
		System.out.println("Current Fee is: " + currentFee);
		
		golfResort();
	}		// end main
				
	public static boolean allowToDive() {		
		if (licence && insurance && tax){
			System.out.print("Enjoy driving your Car ");
		}else {
			System.out.println("Sorry, you cannot drive the car");
		}
		return true;

	} // end 1
		
		
// Q2		
			
	public static void evenNUmbers() {
		System.out.print("Please low number: ");
		int low=sc.nextInt();
		System.out.print("Please high number: ");
		int high=sc.nextInt();
			
		for(int i=low;i<=high;i++) {
			if(i%2==0) 
				continue;			
			System.out.println(i);
		}
			
	}		// end 2
	
// Q3
			
	public static int calcGolfFees() {
		final int juniorfee = 20;
		final int adultfee = 50;
		final int seniorfee = 60;
		
		int curentFee = 0;
		System.out.println("Enter your age ---> ");
		int age = sc.nextInt();
				
		if (age>=60){
			curentFee = seniorfee;
		}
		else if (age>=18-59){
			curentFee = adultfee;
		}
		else if (age>=10-17){
			curentFee = juniorfee;
		}
		else {
			System.out.println("Player is too young");
		}
		
		System.out.println("How many rounds of golf are you paying for (1 ..5);");

		int rounds = sc.nextInt();
		
		System.out.println("What day of week are you playing (MON, TUE, WED, THU, FRI, SAT, SUN ?");
		
		String day = sc.next();
		
		switch(day)
		{
		case "SAT":
			curentFee *= 1.1;
			break;
		case "SUN":
			curentFee *= 1.1;
			break;
		}
		
		return curentFee;
	}
		// 10% extra on weekends
// Q4
	public static void golfResort()	{ 
		String dayOfWeek = sc.next();
		int MonCount = 0, TueCount = 0, WedCount = 0, ThurCount = 0, FriCount = 0, SatCount = 0, SunCount = 0;
	
		System.out.println("Enter days of the week MON-> SUN");
		while(!dayOfWeek.equals("x")) {
			switch(dayOfWeek ){
				case "Mon":
					MonCount++;
					break;
				case "Tue":
					TueCount++;
					break;
				case "Wed":
					WedCount++;
					break;				
				case "Thur":
					ThurCount++;
					break;
				case "Fri":
					FriCount++;
					break;
				case "Sat":
					SatCount++;
					break;
				case "Sun":
					SunCount++;
					break;	
				default:
					System.out.println("Error: "+ dayOfWeek);
					break;
			
			}
			dayOfWeek = sc.next();
		}
			
	
		System.out.println("Golf fee is" + MonCount);
		System.out.println("Golf fee is" + TueCount);
		System.out.println("Golf fee is " + WedCount);
		System.out.println("Golf fee is " + ThurCount);
		System.out.println("Golf fee is " + FriCount);
		System.out.println("Golf fee is " + SatCount);
		System.out.println("Golf fee is" + SunCount);
	}	
}	// end of AssessmentOne

	